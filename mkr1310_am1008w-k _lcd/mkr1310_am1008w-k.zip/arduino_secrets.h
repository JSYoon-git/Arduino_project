// Replace with keys obtained from TheThingsNetwork console
#define SECRET_APP_EUI "xxxxxxxxxxxxx"
#define SECRET_APP_KEY "f16d8486866c9044abc08759f69ca3fa"
